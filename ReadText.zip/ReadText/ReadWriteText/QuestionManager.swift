//
//  QuestionManager.swift
//  ReadWriteText
//
//  Created by Oanh tran on 11/1/18.
//  Copyright © 2018 Seemu. All rights reserved.
//

import Foundation
import SwiftyJSON
import CocoaLumberjackSwift


class QuestionManager {
    
    private let dataManager: DataManager
    
    init(dataManager: DataManager) {
        self.dataManager = dataManager
    }
    func saveAllQuestionToDB(allQuestionFF: [QuestionFF]) {
        allQuestionFF.compactMap { questionFF in
            updateQuestion(questionFF: questionFF)
            return
        }
        firstQuestion()
    }
    
    private func updateQuestion(questionFF: QuestionFF) {
        let question: Question = self.dataManager.insertNew(Question.self)
        question.update(with: questionFF)
        dataManager.saveContext()
    }
    
    private func firstQuestion() -> Question? {
        var result: Question? = nil
        if let question = dataManager.fetchFirst(Question.self) {
            result = question
            print(question.answer)
        } else {
            DDLogInfo("Can't retrieve cached user profile")
        }
        
        return result
    }

}

extension Question {
    
    func update(with questionFF: QuestionFF) {
        unit = questionFF.unit
        part = questionFF.part
        exercise = questionFF.exercise
        answer = questionFF.answer
        number = questionFF.number
        typeAnswer = questionFF.typeAnswer
    }
}


