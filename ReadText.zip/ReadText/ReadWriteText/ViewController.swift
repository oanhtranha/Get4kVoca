//
//  ViewController.swift
//  ReadWriteText
//
//  Created by Andrew on 7/04/2016.
//  Copyright © 2016 Seemu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let allQuestions = importDataInDatabase()
        let dataManager = DataManager()
        let questionManager = QuestionManager(dataManager: dataManager)
        questionManager.saveAllQuestionToDB(allQuestionFF: allQuestions)
        groupData(questionList: allQuestions)
    }
    
    func importDataInDatabase() -> [QuestionFF] {
        let allDataContents = readDataFromLocalFile()
        var questionList : [QuestionFF] = []
        var unit : Int?
        var exercise : String?
        var part : String?
        for line in allDataContents {
            if line.contains("Unit") {
                let unitString: String = line.replacingOccurrences(of: "Unit", with: "")
                unit = Int(unitString.replacingOccurrences(of: " ", with: ""))
                exercise = nil
            }
            if line.contains("Exercise") || line.contains("Reading Comprehension") {
                exercise = line
                part = nil
            }
            
            if line.contains("Part") {
                part = line
            }
            
            if line.contains(".") {
                let splitLine : [String] = line.components(separatedBy: ".")
                let answerType: String = getTypeOfAnswer(answer: splitLine[1])
                
                let question = QuestionFF(number: splitLine[0], answer: splitLine[1], part: part ?? "", exercise: exercise ?? "", unit: Int16(unit ?? 0), typeAnswer: answerType)
                questionList.append(question)
            }
        }
        return questionList
    }
    
    private func getTypeOfAnswer(answer: String) -> String {
        let answerKey =  answer.replacingOccurrences(of: ",", with: "").replacingOccurrences(of: " ", with: "")
        var maxKeyAnswer = 4
        if answerKey.count >= maxKeyAnswer {
            return "text"
        } else {
            answerKey.compactMap { char in
                if ["a", "b", "c", "d"].contains(char) {
                    maxKeyAnswer = maxKeyAnswer - 1
                }
            }
            if maxKeyAnswer == 4 - answerKey.count {
                return "abcd"
            }
        }
        return "text"
    }
    
    func groupData(questionList : [QuestionFF]) {
        
        let groupQuesByUnit = Dictionary(grouping: questionList, by: {$0.unit})
        
        for unitDic in groupQuesByUnit {
            let unit = unitDic.key
            let questOfUnit =  unitDic.value
            print("Unit \(unit)")
            let groupQuestByExercise = Dictionary(grouping: questOfUnit, by: {$0.exercise})
            let groupQuestByExerciseSorted = groupQuestByExercise.sorted(by: { $0.0 < $1.0 })
            
            for exerDic in groupQuestByExerciseSorted {
                let exercise =  exerDic.key
                let questOfExercise = exerDic.value
                print(exercise)
                if let quesPart = questOfExercise[0].part, quesPart != "" {
                    let groupQuestByPart = Dictionary(grouping: questOfExercise, by: {$0.part})
                    for partDic in groupQuestByPart {
                        let part = partDic.key
                        let quesOfPart = partDic.value
                        print(part ?? "")
                        for ques in quesOfPart {
                            print("\(ques.number).\(ques.answer)")
                            if ques.typeAnswer == "abcd" {
                                print("a,b,c,d")
                            } else {
                                print("Enter Text:......")
                            }
                        }
                    }
                } else {
                    for ques in questOfExercise {
                        print("\(ques.number).\(ques.answer)")
                        if ques.typeAnswer == "abcd" {
                            print("a,b,c,d")
                        } else {
                            print("Enter Text:......")
                        }
                    }
                }
            }
        }
    }
    
    func readDataFromLocalFile() -> [String] {
        
        var text: [String] = []
        let fileName = "ProjectTextFile"
        let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        //
        let fileURL = DocumentDirURL.appendingPathComponent(fileName).appendingPathExtension("txt")
        
        /*** Read from project txt file ***/
        
        // File location
        let fileURLProject = Bundle.main.path(forResource: "ProjectTextFile", ofType: "txt")
        // Read from the file
        var readStringProject = ""
        do {
            readStringProject = try String(contentsOfFile: fileURLProject!, encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("Failed reading from URL: \(fileURL), Error: " + error.localizedDescription)
        }
        
        do {
            text = readStringProject.components(separatedBy: "\n")
        } catch {
            Swift.print("Fatal Error: Couldn't read the contents!")
        }
        return text
    }
    
}

enum TypeAnswer {
    case abcd
    case text
}

struct QuestionFF {
    var number: String
    var answer: String
    var part: String?
    var exercise: String
    var unit: Int16
    var typeAnswer: String
}
