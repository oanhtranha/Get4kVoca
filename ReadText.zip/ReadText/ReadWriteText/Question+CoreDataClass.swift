//
//  Question+CoreDataClass.swift
//  ReadWriteText
//
//  Created by Oanh tran on 11/1/18.
//  Copyright © 2018 Seemu. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Question)
public class Question: NSManagedObject {

}
